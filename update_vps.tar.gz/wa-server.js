require('dotenv').config();
const { Client, LocalAuth } = require('whatsapp-web.js');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const sessions = new Map();
const qrCodes = new Map();

// Helper to init client
function initClient(clientId) {
    if (sessions.has(clientId)) {
        return sessions.get(clientId);
    }

    console.log(`[WA] Initializing client for ${clientId}...`);
    const client = new Client({
        authStrategy: new LocalAuth({ clientId }),
        puppeteer: {
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
        }
    });

    client.on('qr', (qr) => {
        console.log(`[WA] QR received for ${clientId}`);
        qrCodes.set(clientId, qr);
    });

    client.on('ready', () => {
        console.log(`[WA] Client ${clientId} is ready!`);
        qrCodes.delete(clientId);
        
        // Optional: trigger Next.js cron for this client if needed
        // triggerNextJsCron(clientId);
    });

    client.on('authenticated', () => {
        console.log(`[WA] Client ${clientId} authenticated`);
        qrCodes.delete(clientId);
    });

    client.on('auth_failure', msg => {
        console.error(`[WA] Auth failure for ${clientId}:`, msg);
        qrCodes.delete(clientId);
        client.destroy().catch(console.error);
        sessions.delete(clientId);
    });

    client.on('disconnected', (reason) => {
        console.log(`[WA] Client ${clientId} disconnected:`, reason);
        qrCodes.delete(clientId);
        client.destroy().catch(console.error);
        sessions.delete(clientId);
    });

    client.initialize().catch(err => {
        console.error(`[WA] Error initializing ${clientId}:`, err);
        sessions.delete(clientId);
    });

    sessions.set(clientId, client);
    return client;
}

app.post('/start', (req, res) => {
    const { clientId } = req.body;
    if (!clientId) return res.status(400).json({ error: 'clientId is required' });

    if (!sessions.has(clientId)) {
        initClient(clientId);
        return res.json({ status: 'STARTING' });
    }
    
    return res.json({ status: 'ALREADY_EXISTS' });
});

app.get('/status/:clientId', (req, res) => {
    const { clientId } = req.params;
    
    if (!sessions.has(clientId)) {
        return res.json({ status: 'NOT_STARTED' });
    }

    const client = sessions.get(clientId);
    
    if (qrCodes.has(clientId)) {
        return res.json({ status: 'QR_READY', qr: qrCodes.get(clientId) });
    }
    
    if (client.info) {
        return res.json({ status: 'READY', pushname: client.info.pushname });
    }

    return res.json({ status: 'STARTING' });
});

app.post('/logout', async (req, res) => {
    const { clientId } = req.body;
    if (!clientId) return res.status(400).json({ error: 'clientId is required' });
    
    if (sessions.has(clientId)) {
        const client = sessions.get(clientId);
        try {
            await client.logout();
        } catch (e) {
            console.error(e);
        }
        sessions.delete(clientId);
        qrCodes.delete(clientId);
    }
    res.json({ success: true });
});

app.post('/send-wa', async (req, res) => {
    const { clientId, number, message } = req.body;
    
    if (!clientId) {
        return res.status(400).json({ error: 'clientId is required for multi-tenant WA' });
    }
    
    if (!sessions.has(clientId)) {
        return res.status(503).json({ error: 'WhatsApp Bot belum siap atau belum di-scan untuk pengguna ini.' });
    }

    const client = sessions.get(clientId);
    
    if (!client.info) {
        return res.status(503).json({ error: 'Client belum terhubung sepenuhnya.' });
    }

    if (!number || !message) {
        return res.status(400).json({ error: 'Number dan Message diperlukan' });
    }

    try {
        const formattedNumber = `${number.replace(/[^0-9]/g, '')}@c.us`;
        await client.sendMessage(formattedNumber, message);
        console.log(`✅ Pesan WA terkirim ke ${number} via clientId ${clientId}`);
        res.json({ success: true });
    } catch (err) {
        console.error(`Gagal mengirim WA via ${clientId}:`, err);
        res.status(500).json({ error: err.message });
    }
});

app.get('/contacts', async (req, res) => {
    const { clientId } = req.query;
    if (!clientId || !sessions.has(clientId)) {
        return res.status(503).json({ error: 'WhatsApp Bot belum siap untuk pengguna ini.' });
    }
    const client = sessions.get(clientId);
    if (!client.info) {
        return res.status(503).json({ error: 'Client belum terhubung sepenuhnya.' });
    }

    try {
        const contacts = await client.getContacts();
        const savedContacts = contacts
            .filter(c => c.isMyContact && !c.isGroup)
            .map(c => ({
                id: c.id._serialized,
                name: c.name || c.pushname || c.shortName || c.number,
                number: c.number
            }));
        savedContacts.sort((a, b) => a.name.localeCompare(b.name));
        res.json({ contacts: savedContacts });
    } catch (err) {
        console.error('Gagal mengambil kontak WA:', err);
        res.status(500).json({ error: err.message });
    }
});

const PORT = 3001;
app.listen(PORT, () => {
    console.log(`\n=========================================`);
    console.log(`🚀 WA Server (Multi-Tenant) berjalan di port ${PORT}`);
    console.log(`=========================================\n`);
});
